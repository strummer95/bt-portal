<?php
/**
 * BT Portal — one URL per tab.
 *
 * The portal is a single page with six panes, so every view shared the same
 * address: you could not send someone to Exchanges, and a refresh always
 * dumped you back on Schedule.
 *
 * /employees/exchanges is a rewrite onto the same page with a query var, so
 * there is still exactly one page in WordPress and no new templates.
 *
 * Three things have to line up or this silently does nothing:
 *   1. the rewrite rule, built from whichever page actually holds the
 *      shortcode rather than a hardcoded "employees"
 *   2. the query var, or WordPress drops it before the page renders
 *   3. redirect_canonical, which otherwise "helpfully" bounces
 *      /employees/exchanges straight back to /employees/
 */
if (!defined('ABSPATH')) exit;

/** URL slug => tab id used by btSwitchTab(). */
function btp_tab_map() {
    return apply_filters( 'btp_tab_map', array(
        'schedule'      => 'schedule',
        'online-stores' => 'stores',
        'stores'        => 'stores',      // convenience alias
        'quote'         => 'quote',
        'redirect'      => 'redirect',
        'contacts'      => 'contacts',
        'exchanges'     => 'exchanges',
        'accounts'      => 'accounts',
        'omg-scanner'   => 'omgscan',
        'scanner'       => 'omgscan',    // convenience alias
        // 'chipply-barcoder' => 'barcoder',   // hidden — see shortcode.php
        // 'barcoder'         => 'barcoder',
        'chipply-scanner'  => 'chipscan',
        'bruce-art'        => 'bruceart',
        'bruce'            => 'bruceart',   // convenience alias
    ) );
}

/** Tab id => canonical slug (the one written into the address bar). */
function btp_tab_slugs() {
    return array(
        'schedule'  => 'schedule',
        'stores'    => 'online-stores',
        'quote'     => 'quote',
        'redirect'  => 'redirect',
        'contacts'  => 'contacts',
        'exchanges' => 'exchanges',
        'accounts'  => 'accounts',
        'omgscan'   => 'omg-scanner',
        // 'barcoder'  => 'chipply-barcoder',  // hidden
        'chipscan'  => 'chipply-scanner',
        'bruceart'  => 'bruce-art',
        'vendors'   => 'vendors',
    );
}

/**
 * The page holding [bt_schedule]. Recorded by the shortcode the first time it
 * renders rather than hardcoded, so moving or renaming the portal page keeps
 * working — the slug is 'employees' today but nothing here depends on that.
 */
function btp_portal_page_id() {
    return (int) get_option('btp_portal_page_id', 0);
}

add_action('init', function() {
    $page_id = btp_portal_page_id();
    if ( ! $page_id ) return;

    $uri = get_page_uri( $page_id );
    if ( ! $uri ) return;

    add_rewrite_rule(
        '^' . preg_quote( $uri, '/' ) . '/([a-z0-9-]+)/?$',
        'index.php?page_id=' . $page_id . '&btp_tab=$matches[1]',
        'top'
    );

    // One thing inside a tab: /employees/accounts/cin-1001. The tab decides
    // what the second part means; the portal only carries it to the page.
    add_rewrite_rule(
        '^' . preg_quote( $uri, '/' ) . '/([a-z0-9-]+)/([a-z0-9-]+)/?$',
        'index.php?page_id=' . $page_id . '&btp_tab=$matches[1]&btp_item=$matches[2]',
        'top'
    );

    // Flush only when the page or the plugin version changed — never per load.
    $stamp = $page_id . '|' . ( defined('BTP_VERSION') ? BTP_VERSION : '0' );
    if ( get_option('btp_rewrite_stamp') !== $stamp ) {
        flush_rewrite_rules( false );
        update_option('btp_rewrite_stamp', $stamp);
    }
}, 20);

add_filter('query_vars', function( $vars ) {
    $vars[] = 'btp_tab';
    $vars[] = 'btp_item';
    return $vars;
});

/**
 * WordPress sees /employees/exchanges resolving to the /employees/ page and
 * wants to 301 to the "correct" URL, taking the tab with it.
 *
 * But redirect_canonical is also what sends boomerts.com to www.boomerts.com.
 * Switching it off wholesale left the portal on the bare host while rest_url()
 * still pointed at www — a different origin, so every API call on the page
 * failed and the tables came up empty.
 *
 * So: allow any redirect that only corrects scheme or host, block only the
 * ones that would change the path and lose the tab.
 */
add_filter('redirect_canonical', function( $redirect, $requested ) {
    if ( ! get_query_var('btp_tab') ) return $redirect;
    if ( ! $redirect || ! $requested )  return $redirect;

    $r = wp_parse_url( $redirect );
    $q = wp_parse_url( $requested );

    $r_path = isset($r['path']) ? untrailingslashit($r['path']) : '';
    $q_path = isset($q['path']) ? untrailingslashit($q['path']) : '';

    // Same path — this is a www/https correction, and it must be allowed
    // through or the page ends up on a host the REST API isn't on.
    if ( $r_path === $q_path ) return $redirect;

    return false;
}, 10, 2);

/** Which tab this request asked for, as a tab id. Empty string if none. */
function btp_requested_tab() {
    $map  = btp_tab_map();
    $slug = get_query_var('btp_tab');

    // ?tab=exchanges also works, and is the fallback when permalinks are plain
    // or the rewrite rules have not been flushed yet.
    if ( ! $slug && isset($_GET['tab']) ) $slug = sanitize_title( wp_unslash($_GET['tab']) );

    $slug = sanitize_title( (string) $slug );
    return isset($map[$slug]) ? $map[$slug] : '';
}

/**
 * Pretty URLs need a permalink structure; on a plain-permalinks site the JS
 * falls back to ?tab= so deep links still work, just uglier.
 */
function btp_pretty_urls() {
    return (bool) get_option('permalink_structure') && btp_portal_page_id();
}

/** Base URL of the portal page, trailing-slashed. */
function btp_portal_base_url() {
    $id = btp_portal_page_id();
    return $id ? trailingslashit( get_permalink( $id ) ) : trailingslashit( home_url('/') );
}

/**
 * Called by the shortcode: remembers which page it lives on, and clears the
 * rewrite stamp when that changes so the rules rebuild on the next request.
 */
function btp_note_portal_page() {
    $id = get_the_ID();
    if ( ! $id || is_admin() ) return;
    if ( (int) get_option('btp_portal_page_id', 0) === (int) $id ) return;

    update_option('btp_portal_page_id', (int) $id);
    delete_option('btp_rewrite_stamp');
}
